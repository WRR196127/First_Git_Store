import pymysql

# 1.创建与数据库连接对象
d=pymysql.connect(
    host="localhost",
    user="root",
    password="123456",
    database="db4",
    charset="utf8")

cur=d.cursor()

# 3.利用游标对象的execute()方法执行SQL命令
cur.execute("insert into sheng values\
    (17,300002,'香港');")

# 4.提交到数据库执行
d.commit()
# 5.关闭游标对象
cur.close()
# 6.断开数据库连接
d.close()


