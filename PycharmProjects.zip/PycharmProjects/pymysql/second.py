import pymysql

db=pymysql.connect(host="localhost",
    user="root",password="123456",
    database="db4",charset="utf8")

cur=db.cursor()

try:
    cur.execute("insert into sheng values(20,900098,'西藏自治区');")
    sql_alter="update sheng set id=667 where id=19;"
    # sql_delete="delete from sheng where s_name='台湾省';"
    cur.execute(sql_alter)
    # cur.execute(sql_delete)
    print('OK')
    db.commit()

except Exception as e:
    db.rollback()
    print("出现错误，回滚",e)

finally:
    cur.close()
    db.close()

