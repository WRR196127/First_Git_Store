from mysqlpython import Mysqlpython

sqlh=Mysqlpython("db4")

sql_update="update sheng set s_name='高丽省'where s_name='云南省';"

# sqlh.exe(sql_update)

sql_fetch="select *from city;"
d=sqlh.select(sql_fetch)
for x in d:
    print(x)