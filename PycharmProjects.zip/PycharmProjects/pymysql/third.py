import pymysql

db=pymysql.connect(host="localhost",
    user="root",password="123456",
    database="db4",charset="utf8")

cur=db.cursor()

try :
    sql_select="select *from sheng;"
    cur.execute(sql_select)

    date1=cur.fetchone()
    date2=cur.fetchmany(4)
    date3=cur.fetchall()
    
    print('**********************')
    print(date1)
    print('**********************')
    for x in date2:
        print(x)
    print('**********************')
    for x in date3:
        print(x)
    print('**********************')
    db.commit()

except Exception as e:
    print(e)

cur.close()
db.close()


