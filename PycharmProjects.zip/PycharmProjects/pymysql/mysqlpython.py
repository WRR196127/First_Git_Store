from pymysql import *

class Mysqlpython:
    def __init__(self,database,host="localhost",user="root",
        password="123456",port=3306,charset='utf8'):

        self.host=host
        self.user=user
        self.password=password
        self.port=port
        self.charset=charset
        self.database=database

    def open(self):
        self.db=connect(host=self.host,user=self.user,port=self.port,
            database=self.database,password=self.password,charset=self.charset)
        self.cur=self.db.cursor()

    def close(self):
        self.cur.close()
        self.db.close()

    def exe(self,sql,l=[]):
        try :
            self.open()
            self.cur.execute(sql,l)
            self.db.commit()
            print("ok")
        except:
            self.db.rollback()
            print("faile")
        self.close()

    def select(self,sql,n=NULL,l=[]):
        try:
            self.open()
            self.cur.execute(sql,l)
            if n is NULL:
                data=self.cur.fetchall()    
            else:
                data=self.cur.fetchmany(n)
          
            self.db.commit()
            return data

        except Exception as e:
            self.db.rollback()
            print("faile",e)
        self.close()    



























