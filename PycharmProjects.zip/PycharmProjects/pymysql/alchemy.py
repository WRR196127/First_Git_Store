from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column,Integer,String

engine=create_eng
Base=declarative_base()#orm基类

class User(Base):
    __tablename__="t123"
    id=Column(Integer,primary_key=True)
    name=Column(String(20))
    address=Column(String(40))

Base.metadata.create_all(engine)    