import pymysql

db=pymysql.connect(host="localhost",
    user="root",password="123456",
    database="db4",charset="utf8")

cur=db.cursor()

s_id=input('请输入省的编号：')
s_name=input('请输入省名称：')

try :
    sql_insert="insert into sheng(s_id,s_name)\
    values(%s,%s);"
    cur.execute(sql_insert,[s_id,s_name])
    db.commit()
    print('OK')

except Exception as e:
    db.rollback()
    print("Failed",e)

cur.close()
db.close()


