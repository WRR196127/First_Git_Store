from pymongo import MongoClient
import gridfs


# 获取grid方案存放到数据库中的文件
conn = MongoClient('localhost',27017)
db = conn.grid

#获取gridfs对象
fs = gridfs.GridFS(db)

#得到文件集合对象
files = fs.find()

#分别取每一个文件
for file in files:
    print(file.filename)
    if file.filename == 'test.mp3':
        with open (file.filename,'wb') as f:
            data = file.read()
            f.write(data)

conn.close()





