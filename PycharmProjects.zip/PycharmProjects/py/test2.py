# def make_power(x):
#     def fn(arg):
#         return arg ** x
#     return fn

# f2 = make_power(2)
# y = f2(100)
# print(y)


# def is_odd(n):
#     return n % 2 == 1
 
# newlist = filter(is_odd, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
# print(list(newlist))


# L=[{2:8,3:5},{1:8,2:5,3:6,4:7},{1:5,2:9,3:6}]
# L.sort(key=len)
# print(L)


# def factorial(n) :
#     if n == 1 :
#         return 1
#     return n * factorial(n - 1)

# print(factorial(5))


def dec(f):
    n = 3
    def wrapper(*args, **kw):
        return f(*args, **kw) * n
    return wrapper

@dec
def foo(n):
    return n * 2

print(foo(2))


def fibs(n):
    if n == 0 or n == 1:
        return 1
    else :
        return fibs(n-1) + fibs(n-2)

print(fibs(4))

def not_empty(s):
    return s and s.strip()

l=list(filter(not_empty, ['A', '', 'B', None, 'C', '  ']))
print(l)