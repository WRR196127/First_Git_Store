# class A:
#     def __init__(self,args):
#        self.__p = args


#     def __priavte(self):
#        print('我是私有方法')

#     def showA(self):
#        print("self.__p=",self.__p)
#        self.__priavte()

# a = A(100)
# a.showA()

# def get_age(a):
#     assert a < 10,'大于10的数字'
#     assert a > 0,'小于等于0？'
#     return a

# print(get_age(12))


# class Test:
#     def prt(self):
#             print(self)
#             print(self.__class__)

# t = Test()
# t.prt()


# def div(x, y):
#     if y == 0:
#         raise ZeroDivisionError("y的值为0")
#     return x / y
# print(div(100,0))


# class A(object):
#     pass

# class B(A):
#     pass 
       
# b = B()
# print(isinstance(b, A) )
# print(isinstance(b, object))
# print(issubclass(B, A))
# print(issubclass(b, B))

class ParentClass1: 
    pass

class ParentClass2: 
    pass

class SubClass1(ParentClass1):
    pass

class SubClass2(ParentClass1,ParentClass2): 
    pass

 print(SubClass1.__bases__)
 print(SubClass2.__bases__)
 print(SubClass1.__bases__)
 print(ParentClass1.__bases__)












































