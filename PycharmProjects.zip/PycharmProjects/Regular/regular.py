import re 

pattern = r'(ab)cd(ef)'
s='abcdefghigklmn'

l = re.findall(pattern,s)
print(l)

regex = re.compile(pattern)
l = regex.findall(s)
print(l)

l = re.split(r'\s+',"Hello  world  nihao  China")
print("split():",l)