import re 

# s='hello world!'

# p = r'Hello'

# r=re.compile(p,flags = re.I)

# print(r.search(s).group())


s='''hello  world
hello kitty
你好，北极，，，，'''

# p=r".+"

# r=re.compile(p,flags = re.S)

p = r'''h\w+   #匹配第一个单词
\s+　　 #匹配多个空格
[a-z]+　 #匹配其他
'''

r=re.compile(p,flags = re.X)

try:
    l=r.search(s).group()
    print(l)
except:
    print('没有匹配到内容')
else:
    print(l)













