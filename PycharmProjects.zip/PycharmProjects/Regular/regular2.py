import re 

pattern = r"(?P<dog>ab)cde(?P<pig>fg)"
regex = re.compile(pattern)

match_obj = regex.search('abcdefghij')

print(match_obj.pos)
print(match_obj.endpos)
print(match_obj.re)
print(match_obj.string)
print(match_obj.lastgroup)
print(match_obj.lastindex)


print('==========================')
print(match_obj.span())
print(match_obj.start())
print(match_obj.end())
print(match_obj.group())
print(match_obj.groupdict())
print(match_obj.groups())












