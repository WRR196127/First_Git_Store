import re 
import sys

def get_address(port):
    f = open('./1.txt')

    while 1:
        data = ''
        for line in f:
            if line !='\n':
                data += line
            else:
                break
        
        if not data:
            return "Not found the port"

        # print(data)
        # print('================================')


        try:
            PORT = re.match(r'\S+',data).group()
            # print(PORT)
        except Exception as e:
            print(e)
            continue

        if PORT == port:
            pattern = r'address is (\w{4}\.\w{4}\.\w{4})'
            addr = re.search(pattern,data).group(1)
            return addr




if __name__ == '__main__':
    port = sys.argv[1]
    print(get_address(port))










