from socket import *

sock_file="./sock_file"

soc=socket(AF_UNIX,SOCK_STREAM)

soc.connect(sock_file)

while 1:
    mss=input('>>')
    if mss:
        soc.send(mss.encode())
        print(soc.recv(1024).decode())
    else:
        break

soc.close()







