from socket import *
import os

sock_file="./sock_file"

if os.path.exists(sock_file):
    os.remove(sock_file)  

soc=socket(AF_UNIX,SOCK_STREAM)

soc.bind(sock_file)
print("文件",sock_file[2:],"已创建，请发送...")

soc.listen(5)

while 1:
    c,addr=soc.accept()
    whilek 1:
        data=c.recv(2048)
        if data:
            print(data.decode(),"接收完毕")
            c.send(b"Receive success")
        else:
            break
    c.close()

soc.close()

















