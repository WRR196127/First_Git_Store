from socket import *
from select import *

#创建套接字
s=socket()
s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
s.bind(('0.0.0.0',1234))
s.listen(5)
print("等待连接.....")

#创建POLL对象
p=epoll()

#fileno--->IO对象的字典
fdmap={s.fileno():s}

l={}

#关注IO注册
p.register(s,EPOLLIN|EPOLLERR)


while 1:
    #进行IO监控
    events=p.poll()
    for fd,event in events:
        if fd == s.fileno():
            c,addr=fdmap[fd].accept()
            print("Connect from",addr)
            p.register(c,EPOLLIN|EPOLLHUP)
            fdmap[c.fileno()]=c
            l[c]=addr
            print("当前客户有%d个"%len(l))

        elif event & EPOLLIN:
            data=fdmap[fd].recv(1024)
            if not data:
                p.unregister(fd)
                fdmap[fd].close()
                print(l[fdmap[fd]],"已挂机！")
                del l[fdmap[fd]]
                del fdmap[fd]
                print("当前客户有%d个"%len(l))
            else:
                print(data.decode())
                print("Come from ",l[fdmap[fd]])
                fdmap[fd].send(b"Receive success!")

    # if  len(l)==0:
    #     n=input('是否继续？（N/Y）')
    #     if n=="n":
    #         break
    #     else:
    #         pass

























