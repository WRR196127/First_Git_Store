from multiprocessing import *
from time import sleep
import os

def worker(sec,name):
    for x in range(3):
        sleep(sec)
        print("I'm %s"%name)
        print("I'm working...")
        print(1,os.getppid())

# p=Process(target = worker,args=(2,"zhang"))
p=Process(target = worker,name="shab",kwargs={"sec":2,"name":"LIe"})

p.start()
print(p.name)
print(2,p.pid)
p.join(1)

print(3,os.getpid())
print(p.is_alive())
print("===========")
sleep(5)
print(p.is_alive())



