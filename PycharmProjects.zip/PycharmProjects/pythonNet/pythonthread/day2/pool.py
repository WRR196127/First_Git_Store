from multiprocessing import Pool
from time import sleep,ctime

def worker(mss):
    sleep(2)
    print(mss)
    return ctime()

#创建进程池
pool=Pool(processes = 4)
s=[]

for x in range(10):
    mss="hello %d"%x
    #将事件放入进程池序列，等待执行
    r=pool.apply_async(func=worker,args=(mss,))
    s.append(r)
    # pool.apply(func=worker,args=(mss,))

#关闭进程池
pool.close()

for _ in range(4):
    sleep(1)
    print("=============")

#回收
pool.join()

for x in s:
    print(x)
    print(x.get())












