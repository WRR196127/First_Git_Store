from multiprocessing import Pipe,Process
from time import sleep,ctime

# 创建管道对象
fd1,fd2 = Pipe(duplex=False)

def fun(name):
    print("xxx")
    sleep(3)
    fd2.send("hello"+str(name))

jobs=[]
for x in range(5):
    p=Process(target=fun,args=(x,))
    jobs.append(p)
    p.start()

for _ in range(5):
    data=fd1.recv()
    print(data)

for x in jobs:
    x.join()