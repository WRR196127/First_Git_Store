from multiprocessing import Process
from time import sleep,ctime

class ClockProcess(Process):
    def __init__(self,value):
        self.value = value
        super().__init__()

    #重写run方法
    def run(self):
        for x in range(5):
            print("The time is {}\r".format(ctime()))
            sleep(self.value)

#创建自定义子进程类的对象
p=ClockProcess(2)

#自动调用run
p.start()
for x in range(5):
    sleep(1)
    print("hello!")
p.join(3)
print("你好")









