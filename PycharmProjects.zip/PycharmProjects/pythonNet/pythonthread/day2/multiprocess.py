from multiprocessing import *
from time import sleep

a=1

def fun():
    sleep(3)
    a=1000
    print("a=",a)
    print("子进程事件")

# 创建进程对象
p=Process(target=fun)

#启动进程
p.start()

sleep(5)
print("这是父进程")

#回收进程
p.join()

print("parent a=",a)


