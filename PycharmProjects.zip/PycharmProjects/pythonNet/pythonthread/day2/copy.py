import os
from multiprocessing import Process

filename = "./byte.txt"
#获取文件大小
size = os.path.getsize(filename)

#复制前半成
def copys():
    f=open(filename,"rb")
    n=size//2
    fw=open("../../../file1.word","wb")

    while 1:
        if n < 1024 :
            fw.write(data)
            break
        data = f.read(1024)
        fw.write(data)
        n -= 1024
    f.close()
    fw.close()

#复制下半部分
def copyf():
    f=open(filename,"rb")
    fw=open("../../../file2.word","wb")

    f.seek(size//2)
    while 1:
        data = f.read(1024)
        if not data:
            break
        fw.write(data)
    fw.close()
    f.close()

p1=Process(target = copys)
p2=Process(target = copyf)
p1.start()
p2.start()
p1.join()
p2.join()





