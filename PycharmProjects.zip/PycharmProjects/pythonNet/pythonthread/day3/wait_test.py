from multiprocessing import Event


e=Event()

print(e.is_set())

e.set()

print(e.is_set())

e.wait(3)

e.clear()

