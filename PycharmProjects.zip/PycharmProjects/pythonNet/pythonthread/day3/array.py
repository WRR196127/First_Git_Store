from multiprocessing import Process,Array
import time as t

# sh=Array('i',[1,2,3,4,5])
# sh=Array('i',5)#开辟５个空间
sh=Array('c',b'hello word')

def fun():
    for i in sh:
        print(i)
    

p=Process(target=fun)
p.start()
p.join()

print(sh.value)
