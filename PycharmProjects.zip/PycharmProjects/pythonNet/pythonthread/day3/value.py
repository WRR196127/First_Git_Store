from multiprocessing import Process,Value
import time as t
import random as r

# 创建共享内存
money=Value("i",2000)
print("初始金额：",money.value)

# 操作共享内存增加
def deposite():
    for x in range(100):
        t.sleep(0.05)
        money.value+=r.randint(1,200)

# 取钱
def withdraw():
    for x in range(100):
        t.sleep(0.05)
        money.value-=r.randint(1,100)

d=Process(target=deposite)
w=Process(target=withdraw)
d.start()
w.start()
d.join()
w.join()

print("剩下的钱：",money.value)








