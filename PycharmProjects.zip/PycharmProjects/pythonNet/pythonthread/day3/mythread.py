from threading import Thread
from time import sleep,ctime 

# class MyThread(Thread):
#     def __init__(self,song,sec):
#         self.song=song
#         self.sec=sec
#         super().__init__()

#     def run(self):
#         for _ in range(2):
#             print("Playing %s %s"%(self.song,ctime()))
#             sleep(self.sec)

# t=MyThread("凉凉",3)
# t.start()
# t.join()


from threading import Thread
from time import sleep,ctime 

class MyThread(Thread):
    def __init__(self,target,name='king',args=(),kwargs={}):
        super().__init__()

        self.name=name
        self.target=target
        self.args=args
        self.kwargs=kwargs
        
    def run(self):
        self.target(*self.args,**self.kwargs)
        
def player(song,sec):
    for _ in range(2):
            print("Playing %s %s"%(song,ctime()))
            sleep(sec)


t=MyThread(target=player,args=("凉凉",3))
t.start()
t.join()


