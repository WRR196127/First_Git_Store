import signal 
from time import sleep 

signal.alarm(10)

# 使用默认方法
# signal.signal(signal.SIGALRM,signal.SIG_DFL)

#忽略信号
signal.signal(signal.SIGALRM,signal.SIG_IGN)
signal.signal(signal.SIGINT,signal.SIG_IGN)

while 1:
    sleep(2)
    print(".....")