from signal import *
import time as t ,os


def han(sig,frame):
    if sig == SIGALRM :
        print("接收到时钟信号...")
    elif sig == SIGINT:
        print("就不结束！")
        t.sleep(3)
        print("好啦....")
        os.kill(os.getpid(),SIGKILL)

alarm(5)

signal(SIGALRM,han)
signal(SIGINT,han)

while 1:
    print("Waiting for signal....")
    t.sleep(1)

