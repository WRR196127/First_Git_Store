from multiprocessing import Queue
from time import sleep

# 创建队列
q=Queue(maxsize=0)

q.put(1,2,3)
sleep(3)
print(q.full())
print(q.get())
print(q.qsize())
