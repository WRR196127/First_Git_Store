from threading import Thread,currentThread 
from time import sleep

def fun():
    sleep(3)
    print("Damon test..")

t=Thread(target=fun)

t.setDaemon(True)
print(t.isDaemon())

t.start()
print("=====主线结束======")
sleep(6)