from threading import Thread,currentThread 
from time import sleep

def fun(sec):
    print("线程属性测试．．．")
    sleep(sec)
    print('%s线程结束'%currentThread().name)

thread=[]
for i in range(3):
    t=Thread(name='king%d'%i,target=fun,args=(2,))
    thread.append(t)
    t.start()
    print("is_alive",t.is_alive())


thread[1].setName('harry')

for x in thread:
    x.join()
