import signal,time as t

signal.alarm(3)
# signal.pause()

i=0
while 1:
    t.sleep(0.1)
    print(i)
    i+=1