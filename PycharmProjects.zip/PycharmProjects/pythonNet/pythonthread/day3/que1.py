from multiprocessing import Process,Queue
import time as t

q=Queue()

def fun1():
    t.sleep(1)
    q.put({"a":1,"b":2})

def fun2():
    t.sleep(2)
    print("收到消息：",q.get())

p1=Process(target=fun1)
p2=Process(target=fun2)
p1.start()
p2.start()
p1.join()

q.close()
p2.join()
