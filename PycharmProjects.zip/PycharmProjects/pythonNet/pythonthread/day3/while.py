import os,signal
from time import sleep,ctime
from multiprocessing import Array,Process

pid = Array('i',12)
def fun():
    pid[0]=os.getpid()
    while 1:
        sleep(1)
        print(ctime(),'\r')

p=os.fork()

if p < 0:
    print("Create process failed!")
elif p == 0:
    fun()
else:
    sleep(10)
    print("已经杀死进程")
    os.kill(pid[0],signal.SIGKILL)




