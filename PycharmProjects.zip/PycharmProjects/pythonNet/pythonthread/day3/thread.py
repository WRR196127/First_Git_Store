import threading
from time import sleep
import os

a=1
def music():
    global a
    for _ in range(5):
        sleep(0.5)
        print("播放葫芦哇",os.getpid())
       
def eat():

    for _ in range(5):
        sleep(1)
        print('吃肯德基',os.getpid())

t=threading.Thread(target=music)
e=threading.Thread(target=eat)
t.start()
e.start()

for _ in range(5):
    sleep(1.3)
    print("美少女战士")

t.join(3)
e.join()
