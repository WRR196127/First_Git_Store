import gevent as g
from time import sleep 

def foo(a,b):
    print("Running in  foo",a,b)
    g.sleep(2)
    print("foo end")

def bar():
    print("Running in  bar")
    g.sleep(3)
    print("bar end")

f = g.spawn(foo,1,2)
b = g.spawn(bar)
print('=================')
g.joinall([f,b],2)
print('=================')
