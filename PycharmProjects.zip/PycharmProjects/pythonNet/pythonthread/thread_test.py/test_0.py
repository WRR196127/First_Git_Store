def count(x,y):
    c=0
    while c<600000:
        c+=1
        x+=1
        y+=1

def write():
    f=open("test.txt",'w')
    for x in range(1000000):
        f.write('hello%d\n'%x)
    f.close()

def read():
    f=open("test.txt")
    lines=f.readlines()
    f.close()