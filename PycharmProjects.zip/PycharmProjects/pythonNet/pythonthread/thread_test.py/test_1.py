from test_0 import *
import time as t

T=t.time()
for  x in range(10):
    count(1,1)

# for i in range(10):
#     write()
#     read()

print("Line cpu",t.time()-T)