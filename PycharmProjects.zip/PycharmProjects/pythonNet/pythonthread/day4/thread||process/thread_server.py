from socket import*
import os , sys 
from threading import *
import traceback

HOST = '0.0.0.0'
PORT = 1222
ADDR = (HOST,PORT)

def handler(c):
    print("Connect from",c.getpeername())
    while 1:
        data = c.recv(1024)
        if not data :
            print(c.getpeername(),"退出")
            break
        print("收到：",data.decode())
        c.send(b"Receive request")
    c.close()

s=socket()
s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
s.bind(ADDR)
s.listen(4)

while 1:
    try :
        c,a = s.accept()
    except KeyboardInterrupt:
        s.close()
        sys.exit("服务器退出．．．．")
    except Exception:
        traceback.print_exc()
        continue

    t=Thread(target = handler,args= (c,))
    t.setDaemon(True)
    t.start()










