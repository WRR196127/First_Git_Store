from socket import*
import os , sys 
from multiprocessing import *
import traceback
from signal import *

HOST = '0.0.0.0'
PORT = 1222
ADDR = (HOST,PORT)

def handler(c):
    print("Connect from",c.getpeername())
    while 1:
        data = c.recv(1024)
        if not data :
            print(c.getpeername(),"退出")
            break
        print("收到：",data.decode())
        c.send(b"Receive request")
    c.close()
    sys.exit(0)

s=socket()
s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
s.bind(ADDR)
s.listen(4)
signal(SIGCHLD,SIG_IGN)

while 1:
    try :
        c,a = s.accept()
    except KeyboardInterrupt:
        s.close()
        sys.exit("服务器退出．．．．")
    except Exception:
        traceback.print_exc()
        continue

    t=Process(target = handler,args= (c,))
    t.DaemonTrue = True
    t.start()










