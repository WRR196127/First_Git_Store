'''
ftp文件服务器
'''

from socket import *
import os
import sys
import time as t
import signal

# 文件库路径
FILE_PATH = "/home/tarena/ftp/"
HOST = "0.0.0.0"
PORT = 8000
ADDR = (HOST,PORT)

#将文件服务器功能封装
class FtpServer(object):
    def __init__(self,c):
        self.con = c

    def do_list(self):
        file_list = os.listdir(FILE_PATH)#获取文件列表
        if not file_list:
            self.con.send("文件为空..".encode())
            return
        else:
            self.con.send(b"OK")
            t.sleep(0.1)

        files = ''
        for file in file_list:
            if file[0] != '.' and os.path.isfile(FILE_PATH + file):
                files = files + file +"#"
        self.con.sendall(files.encode())

    def do_get(self,filename):
        try:
            fd = open(FILE_PATH+filename) 
        except:
            self.con.send("文件打开失败".encode())
            return
        self.con.send(b"OK")
        t.sleep(0.1)
        while 1:
            data = fd.read(1024).encode()
            if not data:
                t.sleep(0.1)
                self.con.send(b"##")
                break
            self.con.send(data)
        print("文件发送完毕")
        fd.close()

    def do_put(self,filename):
        try: 
            fd =open(FILE_PATH+filename,'wb')
        except:
            self.con.send("上传失败！".encode())
            return
        self.con.send(b"OK")
        while 1:
            data = self.con.recv(1024)
            if data == b"##":
                break
            fd.write(data)
        fd.close()
        print("上传完毕！")

# 创建套接字，接收客户端链接，创建新的进程
def main():
    s=socket()
    s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
    s.bind(ADDR)
    s.listen(5)

    signal.signal(signal.SIGCHLD,signal.SIG_IGN)
    print("Listen the port %d..."%PORT)

    while 1:
        try:
            c,a = s.accept()
        except KeyboardInterrupt:
            s.close()
            sys.exit("服务器退出．．")
        except Exception as e:
            print("服务器异常．．",e)
            continue

        print("已连接客户端",a)

        pid = os.fork()
        if pid == 0:
            s.close()
            ftp=FtpServer(c)
            
            while 1:
                data =c.recv(1024).decode()
                if not data or data[0]=="Q":
                    c.close()
                    print("客户端",a,end='')
                    sys.exit("退出...")
                elif data[0] == "L":
                    ftp.do_list()
                elif data[0] == "G":
                    filename = data.split(" ")[-1]
                    ftp.do_get(filename)
                elif data[0] == "P":
                    filename = data.split(" ")[-1]
                    ftp.do_put(filename)
        else:
            c.close()
            continue


if __name__ == "__main__":
    main()


































