from socketserver import *

# 创建服务器类
class Server(ThreadingMixIn,UDPServer):
    pass

class Handler(DatagramRequestHandler):
    def handle(self):
        while 1:
            data = self.rfile.readline()
            if not data:
                break
            print(self.client_address)
            print(data.decode())
            self.wfile.write(b"Receive OK!")
        
if __name__ == "__main__":
    server_addr = ('0.0.0.0',8888)

    # 创建服务器对象
    server = Server(server_addr,Handler)
    # 启动
    server.serve_forever()












