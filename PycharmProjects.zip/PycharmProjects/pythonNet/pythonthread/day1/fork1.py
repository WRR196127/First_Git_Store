import os,time as t

pid = os.fork()

if pid < 0:
    print("Create process failed!")
elif pid == 0:
    # t.sleep(2) 
    print("Child get pid:",os.getpid())
    print("Child get parent pid:",os.getppid())
else:
    print("Parent get child pid:",pid)
    print("Parent get  pid:",os.getpid())





