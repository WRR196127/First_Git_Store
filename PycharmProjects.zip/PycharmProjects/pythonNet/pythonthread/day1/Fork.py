import os ,time as t

pid=os.fork()

if pid < 0:
    print("Error!")

elif pid == 0:
    t.sleep(3)
    print("Child process exit",os.getpid())
    os._exit(2)
​
else:
    while 1:
        pid,status=os.wait()
        print(pid,status)
        print(os.WEXITSTATUS(status))
    while 1:
        pass


import os ,time as t

pid=os.fork()

if pid < 0:
    print("Error!")

elif pid == 0:
    t.sleep(3)
    print("Child process exit",os.getpid())
    os._exit(2)

else:
    while 1:
        t.sleep(2)
        pid,status=os.waitpid(-1,os.WNOHANG)
        print(pid,status)
        print(os.WEXITSTATUS(status))
    while 1:
        pass

import os ,time as t

def f1():
    # t.sleep(3)
    print("第一件事")
def f2():
    # t.sleep(4)
    print("第二件事")

pid=os.fork()

if pid < 0:
    print("Error!")

elif pid == 0:
    #创建二级子进程
    p=os.fork()
    if p==0:
        f2()
    else:
        os._exit(0)
    
else:
   os.wait()
   f1()

