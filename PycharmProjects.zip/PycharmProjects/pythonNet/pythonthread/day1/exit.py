import os,sys

# os._exit(0)
print("process exit")
try :
    sys.exit("bye bye!")
except SystemExit as E:
    print("推出",E)
print("process  asasads exit")