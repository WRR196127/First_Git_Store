import os
import time as t

print("***********************")
a=10

pid=os.fork()

if pid<0:
    print("创建进程失败")
elif pid ==0:
    print("这是新的进程")
    a=10000
    print("a=",a) 
else:
    t.sleep(2)
    print("这是原有进程")
    print('parent a=',a)
print("演示完毕")