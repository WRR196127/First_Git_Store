from socket import *
import os,sys


#创建子进程，登录，创建套接字
def Login():
    if len(sys.argv) < 3:
        peint("argv is error")
        return
    HOST = sys.argv[1]
    PORT = int(sys.argv[2])
    ADDR=(HOST,PORT)

    #创建套接字
    s=socket(AF_INET,SOCK_DGRAM)

    while 1:
        name=input("请输入姓名：")
        msg="L,"+name
        #发送登录请求
        s.sendto(msg.encode(),ADDR)
        #发送服务器回复
        data,addr=s.recvfrom(1024)
        if data.decode() == "OK":
            print("您已进入聊天室！")
            break
        else:
            #不成功回复不允许登录原因
            print(data.decode())

    pid=os.fork()
    if pid < 0 :
        sys.exit("Create child process failed!")
    elif pid == 0 :
        send_mss(s,name,ADDR)
    else :
        recv_mss(s)


def send_mss(s,name,addr):
    while 1:
        text = input("发言：")
        if text.strip() == "quit":
            mss = "Q,"+name
            sys.exit("退出聊天室\n")

        mss= "C,%s,%s"%(name,text)
        s.sendto(mss.encode(),addr)

def recv_mss(s):
    while 1:
        data,addr=s.recvfrom(2048)
        if data.decode() == "EXIT":
            sys.exit(0)
        print(data.decode()+"\n发言：",end="")


if __name__ == "__main__":
    Login()













