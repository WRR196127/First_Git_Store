#! /usr/bin/env python3
#coding=utf-8

'''
name:king Harry
emall:71024399@qq.com
date:2019-03-17
class:AID
introduce:Chatroom server
env:python3.6
'''


from socket import *
import os,sys



#创建网络，进程，调用函数功能函数
def main():
    #server address跑一趟
    ADDR = ('0.0.0.0',1234)

    #创建数据报套接字
    soc=socket(AF_INET,SOCK_DGRAM)
    soc.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
    soc.bind(ADDR)
    
    #创建单独的进程处理管理员喊话
    pid=os.fork()
    if pid < 0:
        sys.exit("Create child process failed!")
    elif pid == 0:
        do_child(soc,ADDR)
    else:
        do_parent(soc)

#接受客户端请求
def do_child(s,addr):
    while 1:
        mss=input("管理员消息：")
        mss="C,管理员,"+mss
        s.sendto(mss.encode(),addr)

#管理员喊话
def do_parent(s):
    user={}  #name:addr 　用户信息统计

    while 1:
        mss,addr=s.recvfrom(1024)
        msslist=mss.decode().split(sep=',')

        #区分请求类型
        if msslist[0] == "L":
            do_login(s,user,msslist[1],addr)
        elif msslist[0] == "C":
            do_chat(s,user,msslist[1]," ".join(msslist[2:]))
        elif msslist[0] == "Q":
            do_quit(s,user,msslist[1])
        
        print("当前用户%d人"%len(user)+"\n管理员消息：")

    

def do_login(s,user,name,addr):
    if (name in user) or name == "管理员":
        s.sendto("\n该用户已存在".encode(),addr)
        return
    s.sendto(b"OK",addr)

    #通知其他人
    mss = "\n欢迎%s进入聊天室"%name
    for x in user:
        s.sendto(mss.encode(),user[x])

    user[name]=addr#加入新成员

def do_chat(s,user,name,text):
    mss="\n%s说:%s"%(name,text)
    for x in user:
        if x != name:
            s.sendto(mss.encode(),user[x])

def do_quit(s,user,name):
    mss = "\n"+name+"退出了聊天室"
    for x in user:
        if x == name:
            s.sendto(b"EXIT",user[x])
        else:
            s.sendto(mss.encode(),user[x])
    del user[name]


if __name__ == "__main__":
    main()









