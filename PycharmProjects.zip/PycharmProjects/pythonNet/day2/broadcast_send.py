from socket import *
from time import sleep

des=('192.168.43.255',2222)
s=socket(AF_INET,SOCK_DGRAM)

s.setsockopt(SOL_SOCKET,SO_BROADCAST,1)

while 1:
    sleep(2)
    s.sendto('来呀，快活呀！'.encode(),des)

s.close()