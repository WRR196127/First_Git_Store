from socket import *

s=socket()
s.connect(('127.0.0.1',1111))

f=open('send.jpg','rb')

while 1:
    data=f.read(1024)
    if not data:
        break
    s.send(data)
print('发送完毕')
f.close()
s.close()