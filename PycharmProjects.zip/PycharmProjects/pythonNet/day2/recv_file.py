from socket import *

s=socket()
s.bind(('127.0.0.1',1111))
s.listen(5)
print('准备接受')
c,addr=s.accept()
print("Connect from",addr)

f=open("recv.jpg","wb")

while 1:
    data=c.recv(1024)
    if not data:
        break
    f.write(data)
print('接受完毕')
f.close()
c.close()
s.close()