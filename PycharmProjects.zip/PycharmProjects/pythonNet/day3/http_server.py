from socket import *

def handleClient(con):
    request=con.recv(4096)
    # print(request)
    request_lines=request.splitlines()
    print(request_lines)
    for line in request_lines:
        print(line.decode())

    try:
        f=open('index1.html')
    except IOError:
        res="HTTP/1.1 404 not found\r\n"
        res+="\r\n"
        res+="=====sorry not found======"
    else:
        res="HTTP/1.1 200 Ok\r\n"
        res+="\r\n"
        res+=f.read()
    finally:
        con.send(res.encode())


def main():
    sock=socket()
    sock.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
    sock.bind(('0.0.0.0',1100))
    sock.listen(5)
    print('listen to the port 1100')    
    while 1:
        con,addr=sock.accept()
        #处理请求
        handleClient(con)
        con.close()
    sock.close()

if __name__=="__main__":
    main()



