from select import select
from socket import*

s=socket()
s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
s.bind(("0.0.0.0",1234))
s.listen(5)
print('正在选择连接....')

rl=[s]
wl=[]
xl=[s]

l={}#统计连接客户

while 1:
    # 提交检测我们关注的IO等待IO发生
    rs,ws,xs=select(rl,wl,xl)

    for r in rs:
        if r is s:
            c,addr=r.accept()
            print("Connect from ",addr)
            rl.append(c)#添加到关注列表
            l[c]=addr
            print('当前用户%d个'%len(l))
        else:
            data=r.recv(1024)
            if  not data:
                print('一个客户端退出')
                rl.remove(r)
                del l[r]
                r.close()
                print('当前用户%d个'%len(l))
            else:
                print("消息：",data.decode(),'　come from',l[r])
                wl.append(r)#将客户端套接字放入wl列表

    for w in ws:
        w.send(b"Receive your message")
        wl.remove(w)

    for x in xs:
        if x is s:
            s.close()

    # if len(l)==0:
    #     n=input("是否继续接收...(Y/N)\n")
    #     if n=='n' or n=="N":
    #         break  
    #     else:
    #         pass
        

# s.close()
    # print(rs)
    # c,addr=rs[0].accept()
    # print("Connect from ",addr)










