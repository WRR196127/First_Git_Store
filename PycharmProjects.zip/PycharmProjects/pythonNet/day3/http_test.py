from socket import *

#创建tcp套接字
s=socket(AF_INET,SOCK_STREAM)

s.bind(('0.0.0.0',1111))
s.listen(5)

while 1:
    c,addr=s.accept()
    print("Connet from",addr)

    data=c.recv(4096)
    print("************************")
    print(data)
    print("************************")

    data='''
    HTTP/1.1 200 OK
    Content-Encoding:utf8
    CONtent-Type:text/html

    <h1>Welcome to tedu</h1>
    <p>这是一个测试</p>
    '''
    c.send(data.encode())
    c.close()

s.close()






