from socket import *
from time import sleep,ctime

s=socket()
s.bind(('127.0.0.1',1234))
s.listen(5)

#设置套接字的超时时间
s.settimeout(3)

n=0
while 1:
    print("Waiting to connect...")
    try:
        c,addr=s.accept()
    except timeout:
        if n>=10:
            print('超时请重连...')
            break
        print(ctime())
        n+=1
        continue
    else:
        print("Connect from",addr)
        while 1:
            data=c.recv(2048).decode()
            if not data:
                break
            print(data)
            c.send(ctime().encode())
        c.close()
print('退出登录...')
s.close()




























