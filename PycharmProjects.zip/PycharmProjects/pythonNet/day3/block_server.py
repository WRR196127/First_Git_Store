from socket import *
from time import sleep,ctime

s=socket()
s.bind(('127.0.0.1',1234))
s.listen(5)

#讲套接字设置为非阻塞
s.setblocking(False)

while 1:
    print("Waiting to connect...")
    try:
        c,addr=s.accept()
    except BlockingIOError:
        sleep(2)
        print(ctime())
        continue
    else:
        print("Connect from",addr)
        while 1:
            data=c.recv(2048).decode()
            if not data:
                break
            print(data)
            c.send(ctime().encode())
        c.close()

s.close()




























