from socket import *

s=socket()
print(s.family)
print(s.type)
s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
print(s.getsockopt(SOL_SOCKET,SO_REUSEADDR))
s.bind(('127.0.0.1 ',1111))
s.listen(5)
print(s.fileno())
print(s.getsockname())
c,addr=s.accept()
print(c.getpeername(),addr)
c.recv(1024)

c.close()
s.close()