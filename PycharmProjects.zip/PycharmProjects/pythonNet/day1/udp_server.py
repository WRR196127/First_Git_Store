from socket import *

#创建数据报套接字
sockfd=socket(AF_INET,SOCK_DGRAM)

#绑定地址
sockfd.bind(('0.0.0.0',7777))

print('准备接受.......\n')
#消息接受发送
while 1 :
    data,addr=sockfd.recvfrom(1024)
    print("Rceive from ('%s',%s)"%addr,data.decode())
    sockfd.sendto('接收到你的消息'.encode(),addr)

sockfd.close()