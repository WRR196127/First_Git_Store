from socket import *
import sys

if len(sys.argv)<3:
    print('''size of sys.argv lack data...
        please run as
        python3 udp_client.py 127.0.0.1''')
    raise 
    
host=sys.argv[1]
port=int(sys.argv[2])
addr=(host,port)


#创建数据报套接字
sockfd=socket(AF_INET,SOCK_DGRAM)

#消息发送
while 1:
    data=input('发送消息：')
    if not data:
        break
    sockfd.sendto(data.encode(),addr)
    data,addr=sockfd.recvfrom(1024)
    print('从服务器收到：',data.decode())

sockfd.close()

#