from socket import *

#创建套接字
sockfd=socket(AF_INET,SOCK_STREAM)

sockfd.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
#绑定地址
sockfd.bind(('0.0.0.0',1112))

#设置监听
sockfd.listen(5)

while True:
    #等待接受连接
    print("Waiting for connect...")
    con,addr=sockfd.accept()
    print("Connect from",addr)

    #接收发消息
    while 1:
        data=con.recv(1024)
        if not data:
            break
        print(data.decode())
        n=con.send(b'Receive messages success')
        print('收到！')
    con.close()

    n=input('是否继续接受(y or n)：')
    if n=='n':
        break

#关闭套接字
sockfd.close()








